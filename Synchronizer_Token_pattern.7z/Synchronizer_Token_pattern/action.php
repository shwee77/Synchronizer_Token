<?php

session_start();

if(!$_SESSION["sess"])
{
      if($_POST['username'] == "admin" && $_POST['pass']=="admin")
      {
      $_SESSION["sess"]=$_POST['username'];
      header('Location: form.php');
      }
      else
      {
        ?> <script>  window.location.href='./index.php';
        alert("Incorrect Username or Password")
      </script>
        <?php
      }
}
else
{
  header('Location: form.php');
exit();
}

 ?>
